import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = "https://bjugchprrzapjjmxzxbo.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqdWdjaHBycnphcGpqbXh6eGJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI1NTM2NzMsImV4cCI6MjA1ODEyOTY3M30.gTwfjkbeKReue8lxraNh8Ol7w3mAyKns2ffdPkFxMNY";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Check admin status on page load
window.addEventListener('DOMContentLoaded', async () => {
    const isAdmin = await checkIsAdmin();
    const newArticleBtn = document.getElementById('newArticleBtn');
    if (!isAdmin) {
        newArticleBtn.style.display = 'none';
    } else {
        newArticleBtn.addEventListener('click', () => {
            document.getElementById('articleForm').style.display = 'block';
        });
    }
});

async function checkIsAdmin() {
    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return false;

        const { data, error } = await supabase
            .from('profiles')
            .select('is_admin')
            .eq('id', user.id)
            .single();

        if (error) {
            console.error('Error checking admin status:', error);
            return false;
        }

        return data?.is_admin || false;
    } catch (error) {
        console.error('Error in checkIsAdmin:', error);
        return false;
    }
}

async function submitArticle() {
    try {
        const isAdmin = await checkIsAdmin();
        if (!isAdmin) {
            alert('Only administrators can publish articles');
            return;
        }

        const form = document.getElementById('articleForm');
        const editId = form.dataset.editId;

        const title = document.getElementById('articleTitle').value;
        const category = document.getElementById('articleCategory').value;
        const content = document.getElementById('articleContent').value;

        if (!title || !category || !content) {
            alert('Please fill in all fields');
            return;
        }

        let result;
        if (editId) {
            result = await supabase
                .from('article')
                .update({ title, category, content })
                .eq('id', editId);
        } else {
            result = await supabase
                .from('article')
                .insert([{ title, category, content }]);
        }

        if (result.error) {
            console.error('Submit error:', result.error);
            alert('Error saving article: ' + result.error.message);
        } else {
            alert(editId ? 'Article updated!' : 'Article published!');
            form.reset();
            form.style.display = 'none';
            delete form.dataset.editId;
            await loadArticles();
        }

    } catch (error) {
        console.error('Error in submitArticle:', error);
        alert('Something went wrong. Please try again.');
    }
}

async function loadArticles() {
    try {
        const isAdmin = await checkIsAdmin();
        const { data: articles, error } = await supabase
            .from('article')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        const articleList = document.getElementById('articleList');
        articleList.innerHTML = articles.map(article => `
            <div class="article">
                <h3>${article.title}</h3>
                <p><strong>Category:</strong> ${article.category}</p>
                <p>${article.content}</p>
                ${isAdmin ? `
                    <div class="admin-controls">
                        <button onclick="window.editArticle('${article.id}')" class="edit-btn">Edit</button>
                        <button onclick="window.deleteArticle('${article.id}')" class="delete-btn">Delete</button>
                    </div>
                ` : ''}
            </div>
        `).join('');
    } catch (error) {
        console.error('Error in loadArticles:', error);
        alert('Error loading articles. Please try again.');
    }
}

window.submitArticle = submitArticle;
window.editArticle = async function(id) {
    const isAdmin = await checkIsAdmin();
    if (!isAdmin) {
        alert('Only administrators can edit articles');
        return;
    }

    const { data, error } = await supabase
        .from('article')
        .select('*')
        .eq('id', id)
        .single();

    if (error) {
        alert('Error fetching article');
        return;
    }

    document.getElementById('articleTitle').value = data.title;
    document.getElementById('articleCategory').value = data.category;
    document.getElementById('articleContent').value = data.content;

    const form = document.getElementById('articleForm');
    form.style.display = 'block';
    form.dataset.editId = id;
};

window.deleteArticle = async function(id) {
    try {
        const isAdmin = await checkIsAdmin();
        if (!isAdmin) {
            alert('Only administrators can delete articles');
            return;
        }

        if (confirm('Are you sure you want to delete this article?')) {
            const { error } = await supabase
                .from('article')
                .delete()
                .match({ id: id });

            if (error) {
                console.error('Delete error:', error);
                alert('Error deleting article: ' + error.message);
            } else {
                alert('Article deleted successfully');
                await loadArticles();
            }
        }
    } catch (err) {
        console.error('Delete error:', err);
        alert('Error deleting article. Please try again.');
    }
};

loadArticles();
