const supabase = supabase.createClient("YOUR_SUPABASE_URL", "YOUR_SUPABASE_ANON_KEY");

async function fetchUserProfile() {
    const user = await supabase.auth.getUser();

    if (!user.data.user) {
        console.error("No user logged in");
        return;
    }

    const { data, error } = await supabase
        .from("users")
        .select("full_name, bio, profile_picture")
        .eq("id", user.data.user.id)
        .single();

    if (error) {
        console.error("Error fetching profile:", error.message);
        return;
    }

    document.getElementById("display_full_name").textContent = data.full_name || "N/A";
    document.getElementById("display_bio").textContent = data.bio || "N/A";
    document.getElementById("display_profile_picture").src = data.profile_picture || "default-profile.png";
}

fetchUserProfile();