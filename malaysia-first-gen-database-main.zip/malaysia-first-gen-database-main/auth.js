import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

// Supabase project URL and anon key
const SUPABASE_URL = "https://bjugchprrzapjjmxzxbo.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqdWdjaHBycnphcGpqbXh6eGJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI1NTM2NzMsImV4cCI6MjA1ODEyOTY3M30.gTwfjkbeKReue8lxraNh8Ol7w3mAyKns2ffdPkFxMNY";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Signup function
async function signUpUser() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const { user, error } = await supabase.auth.signUp({
        email: email,
        password: password,
    });

    if (error) {
        alert(error.message);
    } else {
        alert("Signup successful! Check your email for verification.");
    }
}

// Login function
async function loginUser() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (!email || !password) {
        alert("Please enter both email and password");
        return;
    }

    try {
        const { data: { session }, error } = await supabase.auth.signInWithPassword({
            email: email,
            password: password,
        });

        if (error) {
            console.error('Error:', error.message);
            alert("Login failed: " + error.message);
            return;
        }

        if (session) {
            console.log('Login successful');
            window.location.href = "index.html";
        } else {
            alert("Login failed: No session created");
        }
    } catch (err) {
        console.error('Error:', err);
        alert("Login error: " + err.message);
    }
}

// Event listeners for buttons
if (document.getElementById("signupBtn")) {
    document.getElementById("signupBtn").addEventListener("click", signUpUser);
}

if (document.getElementById("loginBtn")) {
    document.getElementById("loginBtn").addEventListener("click", loginUser);
}