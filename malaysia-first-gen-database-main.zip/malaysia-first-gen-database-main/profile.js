import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const supabaseUrl = "https://bjugchprrzapjjmxzxbo.supabase.co"; // Replace with your actual Supabase URL
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqdWdjaHBycnphcGpqbXh6eGJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI1NTM2NzMsImV4cCI6MjA1ODEyOTY3M30.gTwfjkbeKReue8lxraNh8Ol7w3mAyKns2ffdPkFxMNY"; // Replace with your actual Supabase anon key
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Fetch user profile on page load
document.addEventListener("DOMContentLoaded", async () => {
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
        alert("You need to log in first!");
        window.location.href = "login.html";
        return;
    }

    const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single(); // Ensure this is fetching the correct profile

    if (error) {
        console.error("Error fetching profile:", error);
        return;
    }

    if (data) {
        console.log("Fetched profile data:", data);
        console.log("Admin status:", data.is_admin);
        // Update edit form
        document.getElementById("full_name").value = data.full_name || "";
        document.getElementById("bio").value = data.bio || "";
        
        // Update current profile display
        document.getElementById("current_full_name").textContent = data.full_name || "No name set";
        document.getElementById("current_bio").textContent = data.bio || "No bio set";
        
        if (data.profile_picture) {
            document.getElementById("profile_image").src = data.profile_picture;
            document.getElementById("current_profile_image").src = data.profile_picture;
        }
    }
});

// Handle image upload
async function uploadProfilePicture(file) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const fileName = `public/${user.id}-${Date.now()}-${file.name}`;
    console.log("Uploading file with name:", fileName);

    try {
        const { data, error } = await supabase.storage
            .from('profile-pictures')
            .upload(fileName, file, {
                cacheControl: '3600',
                upsert: true
            });

        if (error) throw error;

        const { data: publicUrlData } = supabase.storage
            .from('profile-pictures')
            .getPublicUrl(fileName);

        console.log("Uploaded file URL:", publicUrlData.publicUrl);
        return publicUrlData.publicUrl;
    } catch (error) {
        console.error("Error uploading image:", error);
        alert("Error uploading image: " + error.message);
        return null;
    }
}

// Handle profile update
window.updateProfile = async function () {
    console.log("updateProfile function triggered!");  // Log here to confirm the function is being called

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
        alert("You need to log in first!");
        return;
    }

    const fullName = document.getElementById("full_name").value.trim();
    const bio = document.getElementById("bio").value.trim();

    console.log("Full Name:", fullName);  // Log to check if full name is captured
    console.log("Bio:", bio);  // Log to check if bio is captured

    const profilePictureInput = document.getElementById("profile_picture");

    let profilePictureUrl = document.getElementById("profile_image").src;

    // Handle profile picture upload
    if (profilePictureInput.files.length > 0) {
        const uploadedUrl = await uploadProfilePicture(profilePictureInput.files[0]);
        if (uploadedUrl) {
            profilePictureUrl = uploadedUrl;
        }
    }

    console.log("Updating profile with URL:", profilePictureUrl); // Log the profile picture URL being updated

    const { error } = await supabase
        .from("profiles")
        .upsert({
            id: user.id,
            full_name: fullName,
            bio: bio,
            profile_picture: profilePictureUrl,
            updated_at: new Date(),
            is_admin: true
        });

    if (error) {
        console.error("Error updating profile:", error);
        alert("Error updating profile: " + error.message);
    } else {
        console.log("Profile updated successfully!");
        alert("Profile updated successfully!");
        document.getElementById("profile_image").src = profilePictureUrl;
    }
};